﻿namespace Events.Services;

public interface IVisitationService
{
    public void SaveFirstVisitation(DateTime date);
    public DateTime? GetFirstVisitation();
    public void RemoveFirstVisitation();
    public string GetFooterMessage();
}