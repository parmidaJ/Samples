﻿namespace Events.Services;

public class VisitationCookieService : IVisitationService
{
    private const string FirstVisited = "last_visited";

    private readonly IHttpContextAccessor _httpContextAccessor;

    public VisitationCookieService(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    private IResponseCookies ResponseCookies => _httpContextAccessor.HttpContext.Response.Cookies;

    private IRequestCookieCollection RequestCookies => _httpContextAccessor.HttpContext.Request.Cookies;

    public void SaveFirstVisitation(DateTime date)
    {
        CookieOptions options = new CookieOptions
        {
            Expires = DateTime.Now.AddDays(30),
        };
        ResponseCookies.Append(FirstVisited, date.ToString(), options);
    }

    public DateTime? GetFirstVisitation()
    {
        string? cookie = RequestCookies[FirstVisited];
        if (string.IsNullOrEmpty(cookie))
        {
            return null;
        }
        else
        {
            return DateTime.Parse(cookie);
        }
    }

    public void RemoveFirstVisitation()
    {
        ResponseCookies.Delete(FirstVisited);
    }
    
     public string GetFooterMessage()
     {
         string msg = "Hey, welcome to the Party Manager App!";

         DateTime? firstVisitation = GetFirstVisitation();
         if (firstVisitation == null)
         {
             SaveFirstVisitation(DateTime.Now);
         }
         else
         {
             msg = $"Welcome back! You first used this app on: {firstVisitation}";
         }

         return msg;
     }
}