﻿using Events.Entities;

namespace Events.Services;

public interface IEmailService
{
    public void SendInvitationEmails(IEnumerable<Invitation> invitations);
}