﻿using Events.Entities;

namespace Events.Models
{
    public class ManagePartyModel
    {
        public Party Party { get; set; }

        public Invitation Invitation { get; set; }
        
        public string PartySummary => $"The party \"{Party.Description}\" is at {Party.Location} on {Party.EventDate.ToShortDateString()}";

        public string InvitationSummary
        {
            get
            {
                var notSent = $"Invites not sent: {Party.Invitations?.Count(i => i.Status == InvitationStatus.InviteNotSent)}";
                var sent = $"Invites sent: {Party.Invitations?.Count(i => i.Status == InvitationStatus.InviteSent)}";
                var yes = $"Yes count: {Party.Invitations?.Count(i => i.Status == InvitationStatus.RespondedYes)}";
                var no = $"No count: {Party.Invitations?.Count(i => i.Status == InvitationStatus.RespondedNo)}";

                return $"{notSent} | {sent} | {yes} | {no}";
            }
        }

        public string InvitationStatusToString(InvitationStatus status)
        {
            return status switch
            {
                InvitationStatus.InviteNotSent => "Invite not sent",
                InvitationStatus.InviteSent => "Invite sent",
                InvitationStatus.RespondedYes => "Responded yes",
                InvitationStatus.RespondedNo => "Responded no",
                _ => "Unknown"
            };
        }
    }
}